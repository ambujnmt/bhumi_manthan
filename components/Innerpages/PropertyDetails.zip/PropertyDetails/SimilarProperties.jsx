import React from 'react'
import { LuBuilding2 } from "react-icons/lu";

export default function SimilarProperties() {
    return (
        <>
            <div className="mt-10">
                {/* Heading */}
                <div className="mb-3 flex items-center gap-2">
                    <LuBuilding2 className="text-[var(--primary-color)]" size={20} />
                    <h2 className="text-lg font-bold text-gray-900 mb-0">
                        Similar Properties
                    </h2>
                </div>

                <div className="grid grid-cols-12 gap-4">
                    <div className="xl:col-span-3 lg:col-span-3 md:col-span-4 col-span-12">
                        <div className="">
                            <img
                                src="/assets/img/similar-property1.png"
                                alt="image"
                                className="h-auto w-full rounded-lg object-cover"
                            />
                            <div className="p-[10px]">
                                <h5 className="text-[14px] text-[#202D47] font-medium">₹6.80 Cr</h5>
                                <h5 className="text-[14px] text-[#202D47] font-medium">Premium Office Space</h5>
                                <p className="text-[12px] text-[#768198] mb-0">
                                    Sector 62, Gurugram · 3,956 sq. ft.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="xl:col-span-3 lg:col-span-3 md:col-span-4 col-span-12">
                        <div className="">
                            <img
                                src="/assets/img/similar-property2.png"
                                alt="image"
                                className="h-auto w-full rounded-lg object-cover"
                            />
                            <div className="p-[10px]">
                                <h5 className="text-[14px] text-[#202D47] font-medium">₹6.80 Cr</h5>
                                <h5 className="text-[14px] text-[#202D47] font-medium">Noida One</h5>
                                <p className="text-[12px] text-[#768198] mb-0">
                                    Sector 62, Noida · 3,956 sq. ft.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="xl:col-span-3 lg:col-span-3 md:col-span-4 col-span-12">
                        <div className="">
                            <img
                                src="/assets/img/similar-property3.png"
                                alt="image"
                                className="h-auto w-full rounded-lg object-cover"
                            />
                            <div className="p-[10px]">
                                <h5 className="text-[14px] text-[#202D47] font-medium">₹6.80 Cr</h5>
                                <h5 className="text-[14px] text-[#202D47] font-medium">Premium Office Space</h5>
                                <p className="text-[12px] text-[#768198] mb-0">
                                    Sector 62, Gurugram · 3,956 sq. ft.
                                </p>
                            </div>
                        </div>
                    </div>
                    <div className="xl:col-span-3 lg:col-span-3 md:col-span-4 col-span-12">
                        <div className="">
                            <img
                                src="/assets/img/similar-property3.png"
                                alt="image"
                                className="h-auto w-full rounded-lg object-cover"
                            />
                            <div className="p-[10px]">
                                <h5 className="text-[14px] text-[#202D47] font-medium">₹6.80 Cr</h5>
                                <h5 className="text-[14px] text-[#202D47] font-medium">Premium Office Space</h5>
                                <p className="text-[12px] text-[#768198] mb-0">
                                    Sector 62, Gurugram · 3,956 sq. ft.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}
