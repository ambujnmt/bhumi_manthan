 
import {FaUser, FaMobileAlt, FaEnvelope, FaBuilding, FaRupeeSign, FaChevronDown } from "react-icons/fa";

export default function PropertySideForm() {
    return (
        <div className="w-full max-w-sm mx-auto overflow-hidden rounded-md border border-gray-200 bg-white shadow-lg">
        {/* Header */}
        <div className="bg-[var(--secondary-color)] px-5 py-3">
            <h3 className="text-lg font-semibold text-white">Enquire Now</h3>
        </div>

            {/* Form */}
            <form className="space-y-3 p-4 sm:p-5">
                {/* Name */}
                <div className="flex items-center gap-3 rounded border border-gray-300 bg-white px-3 focus-within:border-[var(--primary-color)]">
                <FaUser className="shrink-0 text-[var(--secondary-color)]" size={14} />
                <input
                    type="text"
                    placeholder="Your Name *"
                    required
                    className="w-full bg-transparent py-2.5 text-sm text-gray-700 placeholder-gray-500 outline-none"
                />
                </div>

                {/* Mobile */}
                <div className="flex items-center gap-3 rounded border border-gray-300 bg-white px-3 focus-within:border-[var(--primary-color)]">
                <FaMobileAlt className="shrink-0 text-[var(--secondary-color)]" size={14} />
                <input
                    type="tel"
                    placeholder="Mobile Number *"
                    required
                    className="w-full bg-transparent py-2.5 text-sm text-gray-700 placeholder-gray-500 outline-none"
                />
                </div>

                {/* Email */}
                <div className="flex items-center gap-3 rounded border border-gray-300 bg-white px-3 focus-within:border-[var(--primary-color)]">
                <FaEnvelope className="shrink-0 text-[var(--secondary-color)]" size={14} />
                <input
                    type="email"
                    placeholder="Email Address *"
                    required
                    className="w-full bg-transparent py-2.5 text-sm text-gray-700 placeholder-gray-500 outline-none"
                />
                </div>

                {/* Interested In */}
                <div className="relative flex items-center gap-3 rounded border border-gray-300 bg-white px-3 focus-within:border-[var(--primary-color)]">
                <FaBuilding className="shrink-0 text-[var(--secondary-color)]" size={14} />
                <select
                    defaultValue=""
                    className="w-full appearance-none bg-transparent py-2.5 pr-6 text-sm text-gray-700 outline-none"
                >
                    <option value="" disabled>
                    Interested In
                    </option>
                    <option value="residential">Residential Plots</option>
                    <option value="commercial">Commercial Plots</option>
                    <option value="apartment">Apartments</option>
                    <option value="villa">Villas</option>
                    <option value="farmhouse">Farm House</option>
                </select>
                <FaChevronDown
                    className="pointer-events-none absolute right-3 text-gray-500"
                    size={11}
                />
                </div>

                {/* Budget Range */}
                <div className="relative flex items-center gap-3 rounded border border-gray-300 bg-white px-3 focus-within:border-[var(--primary-color)]">
                <FaRupeeSign className="shrink-0 text-[var(--secondary-color)]" size={14} />
                <select
                    defaultValue=""
                    className="w-full appearance-none bg-transparent py-2.5 pr-6 text-sm text-gray-700 outline-none"
                >
                    <option value="" disabled>
                    Budget Range
                    </option>
                    <option value="below-25">Below 25 Lac</option>
                    <option value="25-50">25 Lac - 50 Lac</option>
                    <option value="50-1cr">50 Lac - 1 Cr</option>
                    <option value="1-2cr">1 Cr - 2 Cr</option>
                    <option value="above-2cr">Above 2 Cr</option>
                </select>
                <FaChevronDown
                    className="pointer-events-none absolute right-3 text-gray-500"
                    size={11}
                />
                </div>

                {/* Message */}
                <textarea
                rows={4}
                placeholder="Your Message (Optional)"
                className="w-full resize-none rounded border border-gray-300 bg-white px-3 py-2.5 text-sm text-gray-700 placeholder-gray-500 outline-none focus:border-[var(--primary-color)]"
                />

                {/* Checkbox */}
                <label className="flex cursor-pointer items-start gap-2 text-xs text-gray-600">
                <input
                    type="checkbox"
                    className="mt-0.5 h-4 w-4 shrink-0 accent-[var(--primary-color)]"
                />
                <span>I agree to be contacted by bhumimanthan.com</span>
                </label>

                {/* Submit */}
                <button
                type="submit"
                className="w-full rounded bg-[var(--primary-color)] py-3 text-base font-semibold text-white transition hover:opacity-90"
                >
                Submit Enquiry
                </button>
            </form>
        </div>
    );
}